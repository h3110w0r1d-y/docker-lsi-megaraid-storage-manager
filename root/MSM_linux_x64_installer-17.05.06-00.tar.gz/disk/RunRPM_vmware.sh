#!/bin/sh

./deleteOldVersion.sh
retval=$?
if [ $retval == 1 ]; then
  exit
fi

if [ -f /usr/lib64/libstdc++.so.6 ]; then
      libstdc=1;
      else
      libstdc=0;
      echo "File /usr/lib64/libstdc++.so.6 not found"
      echo "Install the libstdc++ rpm from the OS CD and retry"
      echo "Refer to MSM readme for more details"
      exit 0;
fi

##Check for Third-party library RPM
utils2_rpm=`rpm -qa | grep Lib_Utils2-1 | wc -l`
if [ $utils2_rpm = 0 ]; then
        rpm -ivh Lib_Utils2-1.00-06.noarch.rpm --nodeps
else
	newdate=1352112240
	olddate=`rpm -q --queryformat "%{BUILDTIME}" Lib_Utils2`
	if [ $newdate -gt $olddate ]; then
		rpm -ivh Lib_Utils2-1.00-06.noarch.rpm --force
	fi
	if [ $newdate -eq $olddate ]; then
        	echo "Lib_Utils2 RPM is already installed"
	fi
fi

if [ "$setuptype" = "" ]; then
	setuptype="a"
fi
if [ "$removesnmp" = "" ]; then
	removesnmp=0
fi

##Step 2 : Install MegaRAID Storage Manager 15.05.01-00

rpm -i --test MegaRAID_Storage_Manager-15.05.01-00.noarch.rpm
status=$?
if [ $status = 0 ]; then
  echo "Installing  MegaRAID_Storage_Manager-15.05.01-00"
  rpm -ivh MegaRAID_Storage_Manager-15.05.01-00.noarch.rpm
else
  echo "RPM Installation Failed"
  exit 1
fi

/etc/init.d/vivaldiframeworkd start


uninst="/usr/local/MegaRAID Storage Manager/.__uninst.sh"
echo "echo \"Uninstalling MegaRAID_Storage_Manager-15.05.01-00\" " >> $uninst
echo "rpm -e MegaRAID_Storage_Manager-15.05.01-00" >> $uninst
echo "status=\$?" >>$uninst
echo "if [ \$status -ne 0 ]; then" >> $uninst
echo "     exit 1" >> $uninst
echo "fi" >> $uninst
echo "echo \"Uninstalling Lib_Utils2-1.00-06\" " >> $uninst
echo "rpm -e Lib_Utils2-1.00-06" >> $uninst
echo "status=\$?" >>$uninst
echo "if [ \$status -ne 0 ]; then" >> $uninst
echo "     exit 1" >> $uninst
echo "fi" >> $uninst
echo "echo \"Done.\" " >>$uninst
chmod +x "$uninst"
